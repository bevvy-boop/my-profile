export default defineNuxtConfig({
  compatibilityDate: '2024-11-01',
  devtools: { enabled: true },
  modules: ['@nuxtjs/tailwindcss'],
  app: {
    head: {
      title: 'My Profile',
      meta: [{ name: 'description', content: 'My personal profile website' }],
    },
  },
})
